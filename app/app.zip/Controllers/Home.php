<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $data = [
            'isi' => 'index'
        ];
        return view('Layout/template', $data);
    }
}
