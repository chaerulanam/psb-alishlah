<!DOCTYPE html>
<html>
<meta name="viewport"
    content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">

<link rel="icon" href="<?=base_url();?>/img/favicon.png" type="image/png" />

<title>::Al-Ishlah APP::</title>

<style>
.i-demo {
    margin: 0;
    padding: 0;
}

.i-demo iframe {
    border: 0;
    margin: 0;
    padding: 0;
    font-size: 0;
    width: 100%;
    height: 100vh;
    display: flex;
}
</style>

<body class="i-demo">
    <iframe src="/admin/dashboard"></iframe>



    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/5e44175da89cda5a188591ec/1e0t1qduj';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
    </script>
    <!--End of Tawk.to Script-->

</body>

</html>