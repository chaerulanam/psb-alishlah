<?php
echo view('Layout/head.php');
echo view('Layout/header.php');
echo view('Layout/nav.php');
echo view('Layout/content.php');
echo view('Layout/footer.php');
