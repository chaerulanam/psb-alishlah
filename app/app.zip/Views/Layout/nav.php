<!-- ======= Header ======= -->
<header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">


        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="/" class="logo me-auto"><img src="img/logo-light.png" width="260" height="80" alt=""
                class="img-fluid"></a>
        <!-- <h1 class="logo me-auto"><a href="index.html">Al-Ishlah</a></h1> -->

        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
                <li><a class="nav-link scrollto" href="#agenda">Agenda PSB</a></li>
                <li><a class="nav-link scrollto" href="#pendidikan">Jenjang Pendidikan</a></li>
                <li><a class="nav-link   scrollto" href="#portfolio">Portfolio</a></li>
                <li><a class="nav-link scrollto" href="#alumni">Alumni</a></li>
                <li><a class="nav-link scrollto" href="#faq">FAQ</a></li>
                <li><a class="nav-link scrollto" href="#contact">Kontak</a></li>
                <li><a href="https://psb.al-ishlahtajug.sch.id">Daftar</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->

    </div>
</header><!-- End Header -->